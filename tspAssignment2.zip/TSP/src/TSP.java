
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.EventQueue;

/**
 *
 * @author kartoone
 */
public class TSP {

    // Global distances between cities ...
    // The city "names" are based on positions 0..cities.length-1;
    //  (i.e., city0, city1, city2, ..., citynminus1)
    //  cities[3][4] is the distance between city3 and city4
    public static double cities[][];

    // The city x,y coordinates for displaying the city in a swing window
    public static double cityxy[][];

    // JFrame with custom paint method for displaying current best fit individual
    public static JFrameGA map;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // prompt for filename prefix to load both the distance and xy files
        System.out.print("Which city dataset (eil51, eil76, eil101, att48, usa13509)? ");
        Scanner stdin = new Scanner(System.in);
        String filename = stdin.nextLine();
        File tspfile = new File("tspdata/" + filename+".tsp");
        parseTspFile(tspfile); // side-effect of updating cities and cityxy
        
        // See if we can figure out optimal distance
        File optimaltour = new File("tspdata/" + filename + ".opt.tour");
        Individual optimalpath = null;
        int shortestpath;
        if (!optimaltour.exists()) {
            System.out.print("Optimal tour unknown. What is the optimal tour distance? ");
            shortestpath = Integer.parseInt(stdin.nextLine());
        } else {
            optimalpath = parseOptTourFile(optimaltour);
            shortestpath = optimalpath.fitness;
            System.out.println("Optimal tour FOUND. Shortest path is " + shortestpath);
        }

//      uncomment these lines if you want to see what cities and cityxy look like, don't do this for large datasets        
//        for (double city[] : cities) {
//            System.out.println(java.util.Arrays.toString(city));
//        }
//        for (double city[] : cityxy) {
//            System.out.println(java.util.Arrays.toString(city));
//        }

        // prompt for population size
        System.out.print("Population size (must be multiple of 10)? ");
        int popsize = Integer.parseInt(stdin.nextLine());

        // create the first generation
        Population currentGeneration = new Population(popsize);
        currentGeneration.initializePopulation(popsize);

        // go ahead and display the path of the optimal solution if available
        if (optimalpath!=null) {
            System.out.println("Optimal tour file found! Path distance: " + shortestpath);
        }
        map = new JFrameGA(optimalpath, currentGeneration.getFittest(),"GA");     
        
        /* Create and display the form */
        EventQueue.invokeLater(() -> {
            map.setPreferredSize(new java.awt.Dimension(1000,1000));
            map.setResizable(false);
            map.pack();
            map.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
            map.determineScale();
            map.setVisible(true);    
        });

        // Display intial population and WAIT for user to press enter ... let's JFRAME get a chance to finish loading
        System.out.println("Generation 0: " + currentGeneration.getFittest().fitness);
        // System.out.println("Initial population loaded. Displaying the fittest individual (path) from the initial population. Press any key to continue...");
        // stdin.nextLine();

        int gencnt = 1;
        int lastfitness = currentGeneration.getFittest().fitness;
        while (currentGeneration.getFittest().fitness > shortestpath && gencnt<Integer.MAX_VALUE) {
            Population nextGeneration = new Population(popsize); // new "empty" population initially with a size of 0, but space allocated for popsize individuals 

            // Add all individuals from the current generation to the "selectionpool"
            ArrayList<Individual> selectionPool = new ArrayList<>();
            for(int i=0; i<currentGeneration.popSize; i++) {
                selectionPool.add(currentGeneration.individuals[i]);
            }

            // The basic algorithm - repeat selecting chromsomes from current generation until all have been selected
            // But out of the "subselections" only the best fitness ones (half of the subselections) are ever chosen for crossover
            // Once crossed over, only the BEST crossover offspring is chosen for the mutation step
            // All nine mutation steps are applied individually the best crossover offspring to produce nine new children
            // These nine children plus the original unmodified BEST crossover offspring are returned. Note that this means
            // the BEST fitness member of the current generation is NOT preserved despite what the authors say in their article
            while (!selectionPool.isEmpty()) {
                Individual selected[] = doSelect(selectionPool); 
                Individual crossed[] = doCrossover(selected);
                Individual mutants[] = doMutation(crossed);
                for(int i=0; i<mutants.length; i++) {
                    nextGeneration.addIndividual(mutants[i]);
                }
            }
            gencnt++;

            // print the complete population showing the genes of all individuals every 100000 iterations
            if ((gencnt % 100000) == 0) {
                System.out.println(nextGeneration);
                System.out.println("Generation " + gencnt + ": " + nextGeneration.getFittest().fitness);
            }
            // display new generation best fitness if the fitness has changed
            if (nextGeneration.getFittest().fitness != lastfitness) {
                System.out.println("Generation " + gencnt + ": " + nextGeneration.getFittest().fitness);
                lastfitness = nextGeneration.getFittest().fitness;
                if (map!=null) {
                    map.currentroute = nextGeneration.getFittest();
                    map.repaint();
//                    System.out.println("Press enter to continue..."); 
//                    stdin.nextLine(); // uncomment this line if you want to pause the algorithm each time the fitness changes
                }
            }
            // "promote" the next generation to the currentgeneration
            currentGeneration = nextGeneration; 
        }

        System.out.println(currentGeneration);
        System.out.println("Generation " + gencnt + ": " + currentGeneration.getFittest().fitness);
        System.out.println("Best: " + currentGeneration.getFittest());
        stdin.close();
    }

    // select 10 because of 9 mutations we want to apply (page 50, last paragraph before 3.5.1)    
    private static Individual[] doSelect(ArrayList<Individual> selectionPool) {
        Individual selected[] = new Individual[10]; // let Y=10
        for (int i=0; i<10; i++) {
            selected[i] = selectionPool.remove((int)(Math.random()*selectionPool.size()));
        }
        return selected;
    }

    // traditional crossover requires fixing parent ... too slow
    // so a better approach can be chosen to produce valid offspring
    //   frequencyCrossover: https://pdfs.semanticscholar.org/1174/1fc644ad933f08c5fcd50d9c7a9afdc2545e.pdf
    private static Individual[] doCrossover(Individual[] selected) {
        // first sort the selected individuals
        java.util.Arrays.sort(selected);

        // now pick the top Y/2 (i.e., 5) as the crossover group
        Individual best = selected[0];
        for (int i=1; i<5; i++) {
            selected[i+5] = frequencyCrossover(best, selected[i]);
        }

        return selected; // not really necessary to return anything but it makes the main algorithm easier to read if we do this ... important to note original array is being modified though 
    }

    // better name would be "duplicate" crossover
    // preserve the "duplicates" between the parents (i.e., same city in same position) in the offspring
    // then fill in the rest of the genes by randomly selecting one of the remaining cities not currently in the route
    private static Individual frequencyCrossover(Individual parent1, Individual parent2) {
        Individual offspring = new Individual();
        ArrayList<Integer> genePool = new ArrayList<>();
        for (int i = 0; i < offspring.genes.length; i++) {
            offspring.genes[i] = -1;
            genePool.add(i);
        }

        // 1st pass, copy the genes that match in the parents
        // into the offspring. also remove that gene (i.e., city) from the genePool
        for(int i=0; i<offspring.genes.length; i++) {
            if (parent1.genes[i]==parent2.genes[i]) {
                // genes match!!! put this gene into offspring
                offspring.genes[i] = parent1.genes[i];
                genePool.remove(genePool.indexOf(offspring.genes[i]));
            }
        }
        
        // 2nd pass fill in all the genes with a random
        // city from the genepool 
        for(int i=0; i<offspring.genes.length; i++) {
            if(offspring.genes[i]<0) {
                int randomcityindex = (int) (Math.random()*genePool.size());
                offspring.genes[i] = genePool.remove(randomcityindex);                         
            }
        }
        
        return offspring;
    }

    // perform one or more mutations here, the simplest mutation is swapMutate which swaps the order of two randomly selected cities
    // this article describes NINE different mutation operations: https://pdfs.semanticscholar.org/1174/1fc644ad933f08c5fcd50d9c7a9afdc2545e.pdf
    private static Individual[] doMutation(Individual[] crossed) {
        java.util.Arrays.sort(crossed);        
        Individual best = crossed[0];
        crossed[1] = EsEm(best);   // 1st mutation method EsEm - already completed for you
        crossed[2] = GIm(best);    // 2nd mutation method GIm - To Do: finish this method below
        crossed[3] = GIm2(best);   // 3rd mutation method GIm2 - To Do: finish this method below
        crossed[4] = REsm(best);   // 4th mutation method REsm - To Do: finish this method below
        crossed[5] = TGsEm(best);  // 5th mutation method TGsEm - already completed for you
        crossed[6] = REsEm(best);  // 6th mutation method REsEm - To Do: finish this method below
        crossed[7] = REm(best);    // 7th mutation method REm - To Do: finish this method below
        crossed[8] = OPSm(best);   // 8th mutation method OPSm - To Do: finish this method below
        crossed[9] = MRm(best);    // 9th mutation method MRm - To Do: finish this method below
        return crossed; // again, not really necessary to return because crossed is being manipulated in place ... 
        // but the main algorithm is easier to read if we allow creation of an alias by assigning this return value to a new reference
    }

    // helper function does one thing - swaps the genes at point1 and point2
    // this helper function can be used any time you want to swap two individual genes
    // NOTE!!! If you decide NOT to call swapGenes as part of your mutation algorithm,
    // you MUST remember to call calcFitness on the mutant if you are manipulating the mutant's genes directly
    private static void swapGenes(Individual individual, int point1, int point2) {
        int tmp = individual.genes[point1];
        individual.genes[point1] = individual.genes[point2];
        individual.genes[point2] = tmp;
        individual.calcFitness();
    }

    // EsEm - Ends Exchange mutate (already completed for you)
    // pick a point at random less than halfway through
    // all the genes from 0 to that point-1 will be exchanged with the same number of genes from the end
    private static Individual EsEm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N)/2;
        for(int i=0; i<C1; i++) {
            swapGenes(mutant,i,N-C1+i);
        }
        return mutant;
    }
    
    // GIm - Group Insertion mutate
    // pick a point at random less than halfway through
    // all the genes from 0 to that point-1 will be inserted immediately after the cutpoint 
    private static Individual GIm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N)/2;
        for(int i=0; i<C1; i++) {
            swapGenes(mutant,i,N-C1+i);//not correct
        }
        return mutant;
    }    
    
    // GIm2 - Group Insertion mutate, version 2
    // pick a point randomly, but more than halfway through chromosome.
    // the genes from that point to the end should be
    // moved immediately before the designated point (works out to N-2L where L is the number of genes from that point to the end)
    private static Individual GIm2(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N);
        if(C1 <= N/2){
            C1 += 50;
        }
        int L = N - C1;
        for(int i=0; C1<N; C1++) {
            swapGenes(mutant,N-(2*L),C1);
        }
        return mutant;
    }    
    
    // REsm - Reverse Ends mutate
    // pick two points at random, C1 and C2.
    // all the points from the beginning to C1 will be reversed
    // similarly all the points from C2 to the end will be reversed
    private static Individual REsm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N);
        int C2 = (int) (Math.random() * N);
        for(int i=1; i<C1-i; i++) {
            swapGenes(mutant,i,N-C1+i);
        }
        for(int i=0; i<C2-i; i++) {
            swapGenes(mutant,C2,N-C2+i);
        }
        return mutant;
    }    
    
    // TGsEm - Two Genes Exchange mutate (already done for you, previously called swapMutate)
    // pick two points at random, C1 and C2.
    // swap the position of those two selected cities (genes) within the mutant
    private static Individual TGsEm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N);
        int C2 = (int) (Math.random() * N);
        swapGenes(mutant,C1,C2);
        return mutant;
    }

    // REsEm - Reverse Ends Exchange mutate
    // Same as Ends Exchange but also reverse the order when swapping
    private static Individual REsEm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N)/2;
        for(int i=0; i<C1; i++) {
            swapGenes(mutant,N-C1+i,i);
        }
        return mutant;
    }    

    // REm - Reverse End mutate
    // Same as Reverse Ends mutate, but instead of reversing both ends only do the front end    
    private static Individual REm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N);
        for(int i=0; i<C1; i++) {
            swapGenes(mutant,i,N-C1+i);
        }
        return mutant;
    }    

    // OPSm - One Position swap mutate
    // One position chosen at random and then swapped with its neighbor to the right ... don't forget to wrap around using % operator
    private static Individual OPSm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N);
        for(int i=1; i<C1; i++) {
            swapGenes(mutant,C1,N-C1+i);
        }
        return mutant;
    }    

    // MRm - Middle Reverse mutation
    // Pick two points C1 and C2 randomly (not equal to each other and C1<c2)
    // Swap the order of the genes appearing in between (exclusive to both ends - leave C1 and C2 themselve alone, just the ones in between)
    private static Individual MRm(Individual target) {
        int N = cities.length;
        Individual mutant = new Individual(target); // first make copy of target
        int C1 = (int) (Math.random() * N)/2;
        int C2 = (int) (Math.random() * N) + (C1/2);
        for(int i = 1;i < C1-C2;i++){
            swapGenes(mutant,C1 + i,C2 - i);
        }
        return mutant;
    }    

    // pick a city at random for swapping, but then repeatedly swap with every other city until best option found
    // not one of the mutation methods used by the authors. also, not called by doMutation
    // left to demonstrate a heuristic based mutation tied into the underlying TSP problem
    private static Individual hillclimbMutate(Individual target) {
        Individual mutant = new Individual(target); // first make copy of target
        int mutationi = (int) (Math.random() * cities.length);
        int bestfitness = target.fitness;
        int besti = -1;
        for (int i = 0; i < cities.length; i++) {
            if (i == mutationi) {
                continue; // don't swap with itself
            }
            Individual testIndividual = new Individual(target); // create a new test individual to try out the swap
            swapGenes(testIndividual, mutationi, i);
            if (besti < 0 || testIndividual.fitness < bestfitness) { // LESS because of calcFitness function returning distance as fitness
                besti = i;
                bestfitness = testIndividual.fitness;
            }
        }
        // now do the actual swap on the individual
        swapGenes(mutant, mutationi, besti);
        return mutant;
    }

    // parses any NODE_COORD type TSP file found here: https://www.iwr.uni-heidelberg.de/groups/comopt/software/TSPLIB95/tsp/
    private static void parseTspFile(File f) throws FileNotFoundException {
        Scanner filein = new Scanner(f);
        ArrayList<Double[]> allcities = new ArrayList<>(); // store the xy coords for all cities
        boolean skip = true; // flag for skipping all the header info
        double minx=0;       
        double miny=0; 
        while (filein.hasNextLine()) {
            String line = filein.nextLine().trim();
            if (skip) {
                if (line.startsWith("COMMENT: ")) {
                    System.out.println(line.substring("COMMENT: ".length()));
                }
                if (line.equals("NODE_COORD_SECTION")) {
                    skip = false;
                    line = filein.nextLine().trim(); // go ahead and read the next line since we won't be skipping
                }
            }
            if (line.equals("EOF")) {
                break; // break out of the loop if we have read the last coord
            }
            if (skip || line.equals("")) {
                continue;    // this handles extra whitespace at the beginning or end of the file in case there is a blank line
            }
            String parts[] = line.split("\\s+");
            double x = Double.parseDouble(parts[1]);
            double y = Double.parseDouble(parts[2]);
            if (allcities.isEmpty()) {
                minx = x;
                miny = y;
            }
            if (x<minx) {
                minx = x;
            }
            if (y<miny) {
                miny = y;
            }
            allcities.add(new Double[]{x,y});
        }
        filein.close();
        // see if we need to normalize the input because swing doesn't handle negative coordinates
        // there is no need to move this to the JFrameGA class because we don't ever see the coordinate
        // might as well normalize here since we are dealing with coordinates here
        for (Double[] allcity : allcities) {
            allcity[0] += -minx; // increment every x coordinate by the amount that will move the most negative x coord up to 0
        }
        for (Double[] allcity : allcities) {
            allcity[1] += -miny; // increment every y coordinate by the amount that will move the most negative y coord up to 0
        }
        
        cities = new double[allcities.size()][allcities.size()];
        cityxy = new double[allcities.size()][2];
        for (int i = 0; i < cityxy.length; i++) {
            Double coords[] = allcities.get(i);
            cityxy[i] = new double[]{coords[0],coords[1]};
        }
        filein.close(); // done with the scanner, close it
        // now calculate the distances between all cities and put into array
        for (int i=0; i<allcities.size(); i++) {
            for (int j=0; j<allcities.size(); j++) {
                if (i==j) {
                    cities[i][j] = 0;
                } else {
                    // use pythagorean theorem to calculate distances
                    double diffx = cityxy[i][0]-cityxy[j][0];
                    double diffy = cityxy[i][1]-cityxy[j][1];
                    cities[i][j] = Math.sqrt(diffx*diffx + diffy*diffy);
                }
            }
        }
    }

    // parse the optimal path and create an individual with that path
    private static Individual parseOptTourFile(File f) throws FileNotFoundException {
        Scanner filein = new Scanner(f);
        ArrayList<Integer> pathcities = new ArrayList<>();
        boolean skip = true;
        while (filein.hasNextLine()) {
            String line = filein.nextLine().trim();
            if (skip) {
                if (line.equals("TOUR_SECTION")) {
                    skip = false;
                    line = filein.nextLine().trim(); // go ahead and read the next line since we won't be skipping
                }
            }
            if (line.equals("EOF")) {
                break; // break out of the loop if we have read the last coord
            }
            if (skip || line.equals("")) {
                continue;    // this handles extra whitespace at the beginning or end of the file in case there is a blank line
            }
            int city = Integer.parseInt(line)-1;
            if (city>=0) { // ignore the -1 city that may or may not be at the end of the tour file
                pathcities.add(Integer.parseInt(line)-1); // our cities start at 0 instead of 1
            }
        }
        Individual optimal = new Individual();
        for (int i=0; i<pathcities.size(); i++) {
            optimal.genes[i] = pathcities.get(i);
        }
        optimal.calcFitness();
        return optimal;
    }

}
