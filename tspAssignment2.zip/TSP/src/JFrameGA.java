
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Checkbox;
/**
 *
 * @author kartoone
 */
public class JFrameGA extends javax.swing.JFrame {
    private static final long serialVersionUID = 0x123ABCL;
    int leftmargin = 2;
    int rightmargin = 6;
    int topmargin = 14;
    int bottommargin = 8;
    double scalex; // 
    double scaley; 
    Individual optimalroute;
    Individual currentroute;
    /**
     * Creates new form GACityMap
     */
    public JFrameGA(Individual optimalroute, Individual currentroute, String title) {
        super(title);
        this.currentroute = currentroute;
        this.optimalroute = optimalroute;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics contentg = this.getContentPane().getGraphics();
//        determineScale();
        contentg.drawString("Cities: " + TSP.cities.length, tp(0,0).x, tp(0,0).y);
        drawCities(contentg);
        drawConnections(contentg);
    }

    // determines at what scale to map the city coordinates into window coordinates
    protected void determineScale() {
        // first determine max cityx and max cityy
        double maxx = -1;
        double maxy = -1;
        double minx = -1;
        double miny = -1;
        for (int i = 0; i < TSP.cityxy.length; i++) {
            if (maxx<0 || TSP.cityxy[i][0]>maxx) {
                maxx = TSP.cityxy[i][0];
            }
            if (maxy<0 || TSP.cityxy[i][1]>maxy) {
                maxy = TSP.cityxy[i][1];
            }
            if (minx<0 || TSP.cityxy[i][0]<minx) {
                minx = TSP.cityxy[i][0];
            }
            if (miny<0 || TSP.cityxy[i][1]<miny) {
                miny = TSP.cityxy[i][1];
            }
        }
        Dimension d = getContentPane().getSize();
        scalex = (d.getWidth()-leftmargin-rightmargin)/(maxx-minx);
        scaley = (d.getHeight()-topmargin-bottommargin)/(maxy-miny);
    }

    protected void drawCities(Graphics g) {
        for (int i = 0; i < TSP.cityxy.length; i++) {
            Point p = tp(TSP.cityxy[i][0],TSP.cityxy[i][1]);
            g.fillRect(p.x-2, p.y-2, 4, 4);
        }
    }

    protected void drawRoute(Graphics2D g, Individual route) {
        int citylength = route.genes.length;
        for (int i=0; i<citylength; i++) {
            int city1 = route.genes[i];
            int city2 = route.genes[(i+1)%citylength];
            Point segmentstart = tp(TSP.cityxy[city1][0],TSP.cityxy[city1][1]);
            Point segmentfinish = tp(TSP.cityxy[city2][0],TSP.cityxy[city2][1]);
            g.drawLine(segmentstart.x,segmentstart.y,segmentfinish.x,segmentfinish.y);
        }
    }
    protected void drawConnections(Graphics g) {
        Graphics2D g2d= (Graphics2D) g;
        if (optimalroute!=null) {
            g2d.setColor(new Color(255,0,0,20));
            g2d.setStroke(new BasicStroke(6));
            drawRoute(g2d, optimalroute);
        }
        g2d.setStroke(new BasicStroke(1));
        g2d.setColor(Color.BLACK);
        drawRoute(g2d, currentroute);
    }

    protected Point tp(double x, double y) {
        return new Point((int)Math.round(x*scalex+leftmargin), (int)Math.round(y*scaley+topmargin));
    }

}
