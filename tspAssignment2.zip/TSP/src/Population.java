
/**
 *
 * @author kartoone
 */
public class Population { 

    Individual[] individuals;   // must be initialized by a call to initializePopulation
    int popSize;                // current popSize ... starts at 0, and increases as individuals are added
    
    // generationsize = this is how many individuals will eventually be in a c
    public Population(int generationsize) {
        individuals = new Individual[generationsize]; // allocate space to hold all the individuals that will eventually be in this population
        popSize = 0;
    }
    
    // 
    public void addIndividual(Individual individual) {
        individuals[popSize++] = individual;
        if (popSize == individuals.length) {
            java.util.Arrays.sort(individuals); // only sort once we have completely filled up the population
        }
    } 
    
    //Initialize population, this should only be called for the FIRST generation
    //Subsequent generations should be populated by calling the addIndividual method above
    public void initializePopulation(int size) {
        popSize = size;
        individuals = new Individual[popSize];
        for (int i = 0; i < individuals.length; i++) {
            individuals[i] = new Individual();
        }
        java.util.Arrays.sort(individuals);
    }
    
    //Get the fittest individual
    public Individual getFittest() {
        return individuals[0];
    }

    public String toString() {
        String out = "";
        for (int i = 0; i < individuals.length; i++) {
            out += individuals[i] + "\n";
        }
        return out;
    }
    
}
