
import java.util.ArrayList; 
import java.util.Random;

/**
 *
 * @author kartoone
 */
public class Individual implements Comparable { 
    
    // number of genes equals number of cities
    // each "gene" is a city number, e.g., 
    //  012345 means start at city 0 and then travel to cities 1, 2, 3, 4, 5, and then back to 0
    int genes[] = new int[TSP.cities.length];     
    int fitness = 0; // MAKE SURE to update this with a call to calcFitness any time this individuals gene's have changed
    
    public Individual() {
        //Set genes randomly for each individual
        ArrayList<Integer> genePool = new ArrayList<>();
        for (int i = 0; i < genes.length; i++) {
            genePool.add(i);
        }
        for (int i = 0; i < genes.length; i++) {
            int nextCityIndex = (int) (Math.random()*genePool.size());
            genes[i] = genePool.remove(nextCityIndex);
//            genes[i] = i;  // not much genetic diversity but guarantees valid solution where each city only visited once
        }
        this.calcFitness();        
    }

    public Individual(Individual other) {
        for (int i = 0; i < genes.length; i++) {
            genes[i] = other.genes[i];
        }
        fitness = other.fitness;
    }
    
    //Calculate fitness based on distance between cities
    public void calcFitness() {
        fitness = 0;
        for (int i = 0; i < genes.length; i++) {
            fitness += TSP.cities[genes[i]][genes[(i+1)%genes.length]];
        }
    }
    
    public String toString() {
        String out = "";
        for (int i = 0; i < genes.length; i++) {
            out += (genes[i]+1) + ".";
        }
        out += genes[0]+1; // back to the beginning
        out += " " + fitness;
        return out;
    }

    @Override
    public int compareTo(Object o) {
        Individual other = (Individual) o;
        Integer thisFitness = (Integer) this.fitness;
        return thisFitness.compareTo(other.fitness); // use the minus to easily create lower fitness is better since lower magnitude negative numbers are greater than higher magnitude negative numbers
    }

    @Override 
    public boolean equals(Object o) {
        Individual other = (Individual) o;
        int equalcnt = 0;
        for (int i = 0; i < genes.length; i++) {
            if (genes[i]==other.genes[i]) {
                equalcnt++;
            }
        }
        return (equalcnt/(double)genes.length)>0.98;
    }
    
}
