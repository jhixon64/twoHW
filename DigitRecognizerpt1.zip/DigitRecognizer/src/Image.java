/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kartoone
 */
public class Image {
    public byte imgbytes[][]; // our bytes organized into rows and cols
    public Image(byte imgbytes[][]) {
        this.imgbytes = imgbytes;
    }
    @Override
    public String toString() {
        String out = "";
        for (int i = 0; i < imgbytes.length; i++) {
            byte[] colbytes = imgbytes[i];
            for (int j = 0; j < colbytes.length; j++) {
                byte byteval = colbytes[j];
                out += String.format("%02x",byteval);
            }
            out += "\n";
        }
        return out;
    }
}
