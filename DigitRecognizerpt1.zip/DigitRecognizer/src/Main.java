
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.ArrayList;

/**
 * Darkness prediction algorithm
 *   1. Use training data to determine an average "darkness" for each digit
 *   2. To predict a digit, calculate the "darkness" of a test image file and
 *      predict the digit whose average darkness is closest to the test image file darkness
 *  NOTE darkness is simply the sum of all the grayscale values in the image.
 * 
 * @author kartoone
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // PARSE THE TRAINING DATA
        File labelfile = new File("train-labels-idx1-ubyte");
        File imagefile = new File("train-images-idx3-ubyte");
        ArrayList<Byte> digits = parseLabelFile(labelfile);
        ArrayList<Image> images = parseImageFile(imagefile);
        
        // USE THE PARSED TRAINING DATA TO CALUCLATE "AVERAGE" DARKNESS OF EACH DIGIT
        int darknesses[] = calculateAverageDigitDarkness(digits, images);
        System.out.println("Average darknesses in training set: " + java.util.Arrays.toString(darknesses));
        
        // NOW READ IN THE TEST DATASET
        File testlabelfile = new File("t10k-labels-idx1-ubyte");
        File testimagefile = new File("t10k-images-idx3-ubyte");
        ArrayList<Byte> testdigits = parseLabelFile(testlabelfile);
        ArrayList<Image> testimages = parseImageFile(testimagefile);
        
        // TO DO: UPDATE THIS TO KEEP TRACK OF HOW MANY PREDICTIONS ARE CORRECT
        // Finish the predictDigit method partially implemented near the end of this file
        int successes = 0;
        for (int i=0; i<testimages.size(); i++) {
            int predictedDigit = predictDigit(darknesses,testimages.get(i));
            int actualDigit = testdigits.get(i);
            if (predictedDigit == actualDigit){
                successes++;
            }
        }

        // DISPLAY YOUR ACCURACY HERE BASED ON HOW MANY SUCCESSFUL PREDICTIONS YOU HAD
        System.out.println("Successes: " + successes);
        System.out.println("Accuracy: " + (double)successes/testimages.size());
    }

    public static ArrayList<Image> parseImageFile(File f) throws FileNotFoundException, IOException {
        InputStream filein = new FileInputStream(f);
        byte buffer[] = new byte[4];
        filein.read(buffer);
        int magicnumber = new BigInteger(buffer).intValue();
        if (magicnumber != 2051) {
            System.err.println("Invalid image file!");
            System.exit(1);
        }
        filein.read(buffer);
        int numimages = new BigInteger(buffer).intValue();
        System.out.println("Reading image file ... " + numimages + " images.");
        
        filein.read(buffer);
        int rows = new BigInteger(buffer).intValue();
        filein.read(buffer);
        int cols = new BigInteger(buffer).intValue();
        
        ArrayList<Image> alltheimages = new ArrayList<>(numimages);
        for(int i=0; i<numimages; i++) {
            byte imgbytes[][] = new byte[rows][cols];
            for(int row=0; row<rows; row++) {
                byte colbytes[] = new byte[cols];
                filein.read(colbytes);
                imgbytes[row] = colbytes;
            }
            alltheimages.add(new Image(imgbytes));
        }
        return alltheimages;
    }
    
    public static ArrayList<Byte> parseLabelFile(File f) throws FileNotFoundException, IOException {
        InputStream filein = new FileInputStream(f);
        byte buffer[] = new byte[4];
        filein.read(buffer);
        int magicnumber = new BigInteger(buffer).intValue();
        if (magicnumber != 2049) {
            System.err.println("Invalid label file!");
            System.exit(1);
        }
        filein.read(buffer);
        int numdigits = new BigInteger(buffer).intValue();
        System.out.println("Reading label file ... " + numdigits + " digits.");
        ArrayList<Byte> allthedigits = new ArrayList<>(numdigits);
        for(int i=0; i<numdigits; i++) {
            byte b[] = new byte[1];
            filein.read(b);
            allthedigits.add(b[0]);
        }
        return allthedigits;
    }

    // digits has an authoritative "answer" for the digit that is in each image
    // in other words, digits.get(0) returns the digit that corresponds to images.get(0)
    private static int[] calculateAverageDigitDarkness(ArrayList<Byte> digits, ArrayList<Image> images) {
        int darknesstotals[] = new int[10];
        int darknesscount[] = new int[10];
        int darknesses[] = new int[10];
        // TO DO: loop through all the images and calculate the darkness
        // in each image by using the processImage function I have given you below.
        // Add this to the darkness total for the digit specified as the "answer" for that image.
        // Also increment the count of the number of times that particiular digit was encountered so you can properly calculate the average.
        // Finally, calculate the averages by dividing the totals by the counts in each position.
        for (int i = 0; i < darknesses.length; i++) {
            darknesstotals[i] = processImage(images.get(i));
            darknesscount[i] = digits.get(i);
            if(darknesscount[i] != 0){
                darknesses[i] = darknesstotals[i] / darknesscount[i];
            }else {
                darknesses[i] = darknesstotals[i];
            }
        }
        return darknesses;
    }
    
    // calculates the darkness of an image
    // by summing up all the grayscale values
    // in the byte array. Java bytes are all
    // signed, but we can convert them to unsigned
    // bytes (i.e., positive numbers) by performing
    // a bitwise AND operation to zero out the high order bits.
    private static int processImage(Image img) {
        int total = 0;
        for (int i = 0; i < img.imgbytes.length; i++) {
            for (int j = 0; j < img.imgbytes[i].length; j++) {
                total+=img.imgbytes[i][j]&0xFF;                
            }
        }
        return total;
    }

    // return your prediction by calculating the darkness of the image using the
    // processImage method and comparing it to each of the darkness values in the
    // darknesses array. Return the index of the position that has the closest 
    // darkness match.
    private static int predictDigit(int[] darknesses, Image img) {
        int darkness = processImage(img);
        int bestDifference = Integer.MAX_VALUE;
        int bestDifferencei = 0;
        for (int i = 0; i <darknesses.length; i++){
            int difference = Math.abs(darknesses[i]-darkness);
            if (difference<bestDifference){
                bestDifferencei = i;
                bestDifference = difference;
            }
        }
        // done: loop through all the darknesses and update bestdiff and bestdiffi appropriately
        return bestDifferencei;
    }
}
